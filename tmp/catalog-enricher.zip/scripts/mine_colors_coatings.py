import os, re, json
from collections import Counter
from google.cloud import bigquery
import requests

ORG=os.environ["ORG"]
PROJECT=os.environ.get("PROJECT_ID","my-project-39021-1686504586397")
DATASET=os.environ.get("BQ_DATASET","roofing_saas")
TABLE=os.environ.get("BQ_TABLE_CURRENT","master_products_current")

SB_URL=os.environ["SB_URL"].rstrip("/")
SB_KEY=os.environ["SB_KEY"]
h={"apikey":SB_KEY,"Authorization":f"Bearer {SB_KEY}"}

sj=requests.get(
    f"{SB_URL}/rest/v1/bot_settings?select=settings_json&organization_id=eq.{ORG}&limit=1",
    headers=h, timeout=30
).json()[0]["settings_json"]

wl=set((sj.get("pricing") or {}).get("defaults",{}).get("ral_classic_codes",[]) or [])
print("whitelist size:", len(wl))

client = bigquery.Client(project=PROJECT)

sql = f"SELECT title FROM `{PROJECT}.{DATASET}.{TABLE}` WHERE organization_id=@org"
job = client.query(sql, job_config=bigquery.QueryJobConfig(
    query_parameters=[bigquery.ScalarQueryParameter("org","STRING",ORG)]
))
titles=[r["title"] or "" for r in job.result()]

ral=Counter(); rr=Counter(); decor=Counter(); names=Counter(); coatings=Counter()

re_ral = re.compile(r"\bRAL\s*(\d{4})\b", re.I)
re_rr  = re.compile(r"\bRR\s*-?\s*(\d{2})\b", re.I)

DECOR_HINTS=["дуб","орех","кирпич","камень","дерево","сосна","вишня","мрамор","гранит",
             "поддуб","под дуб","под орех","под камень","под кирпич"]
COLOR_WORDS=["шоколад","графит","серый","черный","белый","красный","зеленый","синий","коричневый","бежевый"]
COATING_HINTS=["полиэстер","polyester","pe",
               "pural","пурал","purman","пурман",
               "pvdf","пвдф",
               "plastisol","пластизол",
               "оцинк","оцинковка","zinc","zn",
               "aluzinc","алюцинк",
               "matt","мат","матовый","matte",
               "viking","vikingmp","valori","granite","quarzit","atlas","purman","pur"]

def norm(s): return re.sub(r"\s+"," ",(s or "").strip().lower())

for t in titles:
    tl=norm(t)

    for m in re_ral.finditer(tl):
        code="RAL"+m.group(1)
        if code in wl:
            ral[code]+=1

    for m in re_rr.finditer(tl):
        rr["RR"+m.group(1)] += 1

    for w in DECOR_HINTS:
        if w in tl:
            decor[w.upper().replace(" ","_")] += 1

    for w in COLOR_WORDS:
        if w in tl:
            names[w.upper()] += 1

    for h in COATING_HINTS:
        if h in tl:
            coatings[h.upper()] += 1

out={
 "defaults":{
   "colors_suggested":{
     "ral_top": ral.most_common(120),
     "rr_top": rr.most_common(120),
     "decor_top": decor.most_common(120),
     "name_top": names.most_common(120),
   },
   "coatings_suggested": coatings.most_common(220),
 }
}

open("/tmp/color_coating_suggest.json","w",encoding="utf-8").write(json.dumps(out, ensure_ascii=False, indent=2))
print("WROTE /tmp/color_coating_suggest.json")
print("TOP RAL:", out["defaults"]["colors_suggested"]["ral_top"][:15])
print("TOP RR:", out["defaults"]["colors_suggested"]["rr_top"][:10])
print("TOP DECOR:", out["defaults"]["colors_suggested"]["decor_top"][:10])
print("TOP COATINGS:", out["defaults"]["coatings_suggested"][:10])
