import os, json, requests, sys

ORG=os.environ["ORG"]
SB_URL=os.environ["SB_URL"].rstrip("/")
SB_KEY=os.environ["SB_KEY"]
if not SB_KEY:
    print("ERROR: SB_KEY empty"); sys.exit(1)

wl=json.load(open("/tmp/ral_classic_whitelist.json","r",encoding="utf-8"))
codes=wl.get("ral_classic_codes") or []
print("local whitelist count:", len(codes))

def deep_merge(a,b):
    if isinstance(a, dict) and isinstance(b, dict):
        out=dict(a)
        for k,v in b.items(): out[k]=deep_merge(out.get(k), v)
        return out
    return b

h={"apikey":SB_KEY,"Authorization":f"Bearer {SB_KEY}","Content-Type":"application/json"}

row = requests.get(
    f"{SB_URL}/rest/v1/bot_settings?select=id,settings_json&organization_id=eq.{ORG}&limit=1",
    headers=h, timeout=30
).json()[0]

row_id=row["id"]
settings=row.get("settings_json") or {}
if not isinstance(settings, dict): settings={}

patch={"pricing":{"defaults":{"ral_classic_codes": codes}}}
new_settings=deep_merge(settings, patch)

u=requests.patch(f"{SB_URL}/rest/v1/bot_settings?id=eq.{row_id}", headers=h, json={"settings_json": new_settings}, timeout=30)
u.raise_for_status()
print("OK: saved pricing.defaults.ral_classic_codes =", len(codes))
