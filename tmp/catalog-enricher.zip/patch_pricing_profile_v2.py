from pathlib import Path
import re

p = Path("main.py")
s = p.read_text(encoding="utf-8")

if "def load_pricing_profile(" in s:
    print("OK: load_pricing_profile already exists")
    raise SystemExit(0)

# 1) Найдём функцию sb_headers (она есть у тебя) и вставим после неё
m1 = re.search(r"^def\s+sb_headers\s*\(.*\):\s*\n", s, flags=re.M)
if not m1:
    raise SystemExit("ERROR: def sb_headers(...) not found in main.py")

rest = s[m1.end():]
m2 = re.search(r"^\n(?:def\s+\w+\s*\(|@app\.)", rest, flags=re.M)
end = m1.end() + (m2.start() if m2 else len(rest))

insert = r'''

def load_pricing_profile(organization_id: str) -> dict:
    """
    Always returns MERGED settings profile:
      merged = {**settings_json, **settings_json.get('pricing', {})}
    Works regardless of whether defaults/aliases live in root or pricing.*.
    """
    if not SUPABASE_URL or not SUPABASE_SERVICE_KEY:
        return {}

    base = SUPABASE_URL.rstrip("/")
    url = f"{base}/rest/v1/bot_settings?select=settings_json&organization_id=eq.{organization_id}&limit=1"
    r = requests.get(url, headers=sb_headers(), timeout=30)
    if r.status_code >= 300:
        return {}
    rows = r.json() or []
    if not rows:
        return {}

    settings = rows[0].get("settings_json") or {}
    if not isinstance(settings, dict):
        return {}

    pr = settings.get("pricing")
    if isinstance(pr, dict):
        merged = dict(settings)
        for k, v in pr.items():
            merged[k] = v
        return merged

    return settings
'''
s = s[:end] + insert + s[end:]
p.write_text(s, encoding="utf-8")
print("✅ inserted load_pricing_profile after sb_headers")

# 2) Заменим вызовы старой функции профиля (если есть) на новую
# Частые варианты имён: load_org_profile, sb_get_org_enrich_profile
s2, n1 = re.subn(r"\bload_org_profile\s*\(", "load_pricing_profile(", s)
s2, n2 = re.subn(r"\bsb_get_org_enrich_profile\s*\(", "load_pricing_profile(", s2)

p.write_text(s2, encoding="utf-8")
print(f"✅ replaced calls: load_org_profile({n1}), sb_get_org_enrich_profile({n2})")
