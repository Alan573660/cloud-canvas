from pathlib import Path
import re

p = Path("main.py")
s = p.read_text(encoding="utf-8")

# 1) Insert helper _json_safe if not present
if "_json_safe(" not in s:
    insert_after = r"app\s*=\s*FastAPI[^\n]*\n"
    m = re.search(insert_after, s)
    if not m:
        raise SystemExit("Cannot find FastAPI init to insert helper")

    helper = r'''
def _json_safe(obj):
    """Make object JSON-serializable (datetime -> iso, recursion for dict/list)."""
    import datetime as _dt
    if obj is None:
        return None
    if isinstance(obj, (str, int, float, bool)):
        return obj
    if isinstance(obj, (_dt.datetime, _dt.date)):
        # always ISO
        try:
            return obj.isoformat()
        except Exception:
            return str(obj)
    if isinstance(obj, dict):
        return {str(k): _json_safe(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_json_safe(x) for x in obj]
    # fallback
    return str(obj)

'''
    s = s[:m.end()] + helper + s[m.end():]
    print("✅ inserted _json_safe")
else:
    print("OK: _json_safe already exists")

# 2) Patch the call that writes to Supabase in dry_run: ensure we pass json-safe object
# We replace: sb_patch_import_job_summary(req.import_job_id, { ... })
# with: sb_patch_import_job_summary(req.import_job_id, _json_safe({ ... }))
pattern = r"sb_patch_import_job_summary\(\s*req\.import_job_id\s*,\s*\{"
if re.search(pattern, s):
    s = re.sub(pattern, r"sb_patch_import_job_summary(req.import_job_id, _json_safe({", s, count=1)
    print("✅ wrapped enrich payload with _json_safe(")
else:
    print("⚠️ did not find sb_patch_import_job_summary(req.import_job_id, { pattern)")

# 3) Close the extra parenthesis after the payload dict ends.
# We find the first occurrence of '})' after that call and replace with '}))'
# safest: replace only once.
s = s.replace("})\n", "})))\n", 1)

p.write_text(s, encoding="utf-8")
print("✅ main.py patched")
