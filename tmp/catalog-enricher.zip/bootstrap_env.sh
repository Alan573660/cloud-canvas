#!/usr/bin/env bash
set -euo pipefail

gcloud config set project "my-project-39021-1686504586397" >/dev/null

export ORG="d267278c-8a53-42db-a5a7-2871e946db66"
export JOB="28dcd3b0-8479-4cbe-bd68-be6cf46d0b18"
export SERVICE_URL="$(gcloud run services describe catalog-enricher --region us-central1 --format='value(status.url)')"

export SB_URL="https://okxnlbndsifsrisrgcst.supabase.co"
export SB_KEY="${SUPABASE_SERVICE_ROLE_KEY:-}"

echo "ORG=$ORG"
echo "JOB=$JOB"
echo "SERVICE_URL=$SERVICE_URL"
echo "SB_URL=$SB_URL"
echo "SB_KEY_len=${#SB_KEY}"
