from pathlib import Path
import re

p = Path("main.py")
s = p.read_text(encoding="utf-8")

# 1) Insert new function load_pricing_profile() once, right after sb_url() helper.
if "def load_pricing_profile(" not in s:
    # find sb_url() definition end
    m = re.search(r"^def\s+sb_url\s*\(.*?\):\s*\n(?:.*\n)+?\n", s, flags=re.M)
    if not m:
        raise SystemExit("ERROR: cannot find sb_url() block to insert after")

    insert = r'''

def load_pricing_profile(organization_id: str) -> dict:
    """
    Always returns merged settings profile:
      merged = {**settings_json, **settings_json.get('pricing', {})}
    So code can read defaults/aliases from either root or pricing.* without guessing.
    """
    if not SUPABASE_URL or not SUPABASE_SERVICE_KEY:
        return {}
    url = sb_url(f"/rest/v1/bot_settings?select=settings_json&organization_id=eq.{organization_id}&limit=1")
    r = requests.get(url, headers=sb_headers(), timeout=30)
    if r.status_code >= 300:
        return {}
    rows = r.json() or []
    if not rows:
        return {}
    settings = rows[0].get("settings_json") or {}
    if not isinstance(settings, dict):
        return {}
    pr = settings.get("pricing")
    if isinstance(pr, dict):
        merged = dict(settings)
        for k, v in pr.items():
            merged[k] = v
        return merged
    return settings

'''
    s = s[:m.end()] + insert + s[m.end():]
    print("✅ inserted load_pricing_profile()")
else:
    print("OK: load_pricing_profile already exists")

# 2) Replace all uses of load_org_profile(org) -> load_pricing_profile(org)
# We do it safely only when it's called as a function.
s2, n = re.subn(r"\bload_org_profile\s*\(", "load_pricing_profile(", s)
print(f"✅ replaced load_org_profile(...) calls: {n}")

# 3) If there is no load_org_profile in file, still OK.
p.write_text(s2, encoding="utf-8")
print("✅ main.py patched")
