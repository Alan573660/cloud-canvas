
from pathlib import Path
import re

p = Path("main.py")
s = p.read_text(encoding="utf-8")

if "def load_pricing_profile(" in s:
    print("OK: load_pricing_profile already exists")
    raise SystemExit(0)

# Anchor: after FastAPI app init OR after ENV block start
m = re.search(r"app\s*=\s*FastAPI[^\n]*\n", s)
if not m:
    raise SystemExit("ERROR: cannot find FastAPI app init in main.py")

insert = r"""

def load_pricing_profile(organization_id: str) -> dict:
    \"\"\"
    Always returns MERGED settings profile:
      merged = {**settings_json, **settings_json.get('pricing', {})}
    Works regardless of whether defaults/aliases live in root or pricing.*.
    \"\"\"
    # Build headers locally (do not rely on sb_headers/sb_url existing)
    if not SUPABASE_URL or not SUPABASE_SERVICE_KEY:
        return {}

    base = SUPABASE_URL.rstrip("/")
    url = f"{base}/rest/v1/bot_settings?select=settings_json&organization_id=eq.{organization_id}&limit=1"
    headers = {
        "apikey": SUPABASE_SERVICE_KEY,
        "Authorization": f"Bearer {SUPABASE_SERVICE_KEY}",
        "Content-Type": "application/json",
    }
    r = requests.get(url, headers=headers, timeout=30)
    if r.status_code >= 300:
        return {}
    rows = r.json() or []
    if not rows:
        return {}

    settings = rows[0].get("settings_json") or {}
    if not isinstance(settings, dict):
        return {}

    pr = settings.get("pricing")
    if isinstance(pr, dict):
        merged = dict(settings)
        for k, v in pr.items():
            merged[k] = v
        return merged

    return settings
"""

# Insert after app init
s = s[:m.end()] + insert + "\n" + s[m.end():]
p.write_text(s, encoding="utf-8")
print("✅ inserted load_pricing_profile() after FastAPI init")

# Replace common old calls if present
s = p.read_text(encoding="utf-8")
s2, n1 = re.subn(r"\bload_org_profile\s*\(", "load_pricing_profile(", s)
s2, n2 = re.subn(r"\bsb_get_org_enrich_profile\s*\(", "load_pricing_profile(", s2)
p.write_text(s2, encoding="utf-8")
print(f"✅ replaced calls: load_org_profile({n1}), sb_get_org_enrich_profile({n2})")
