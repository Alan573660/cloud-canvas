from pathlib import Path
import re

p = Path("main.py")
s = p.read_text(encoding="utf-8")

if "def _ai_json_array_call(" in s:
    print("OK: _ai_json_array_call already exists")
    raise SystemExit(0)

# Найти конец функции gemini_suggest (вставим сразу после неё)
m = re.search(r"^def\s+gemini_suggest\([^\)]*\)\s*->\s*List\[Dict\[str,\s*Any\]\]\s*:\s*\n", s, flags=re.M)
if not m:
    raise SystemExit("ERROR: cannot find def gemini_suggest(...)")

# Найдём конец блока функции: следующая top-level def/app.get/app.post или конец файла
rest = s[m.end():]
m2 = re.search(r"^\n(?:def\s+\w+\(|@app\.)", rest, flags=re.M)
end = m.end() + (m2.start() if m2 else len(rest))

wrapper = r'''

def _ai_json_array_call(profile: Dict[str, Any], titles: List[str], task_payload: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Strict AI call wrapper for this project.
    - Uses Gemini (Vertex) through gemini_suggest(profile, titles)
    - Returns list (JSON array) or []
    - task_payload is kept for future multi-task prompts (logged/saved in summary if needed)
    """
    try:
        # Current implementation: gemini_suggest already returns list[dict] or []
        out = gemini_suggest(profile, titles)
        if isinstance(out, list):
            return out
        return []
    except Exception:
        return []
'''
s2 = s[:end] + wrapper + s[end:]
p.write_text(s2, encoding="utf-8")
print("✅ inserted _ai_json_array_call after gemini_suggest")
