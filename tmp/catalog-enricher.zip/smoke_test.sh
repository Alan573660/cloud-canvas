#!/usr/bin/env bash
set -euo pipefail

# require env
: "${ORG:?}"
: "${JOB:?}"
: "${SERVICE_URL:?}"
: "${SB_URL:?}"
: "${SB_KEY:?}"

echo "== HEALTH =="
curl -s "$SERVICE_URL/health" | jq .

echo "== BQ CURRENT METRICS =="
bq query --use_legacy_sql=false --format=prettyjson "
SELECT
  COUNT(*) AS total,
  COUNTIF(coating IS NOT NULL AND coating!='') AS coating_filled,
  COUNTIF(width_work_mm IS NOT NULL) AS width_work_filled,
  COUNTIF(width_full_mm IS NOT NULL) AS width_full_filled,
  COUNTIF(thickness_mm IS NOT NULL) AS thickness_filled,
  COUNTIF(REGEXP_CONTAINS(notes, r'\\bral=\\d{4}\\b')) AS ral_tagged
FROM \`my-project-39021-1686504586397.roofing_saas.master_products_current\`
WHERE organization_id='${ORG}'
" | jq .

echo "== BOT_SETTINGS pricing.* =="
curl -s "${SB_URL}/rest/v1/bot_settings?select=settings_json&organization_id=eq.${ORG}&limit=1" \
  -H "apikey: ${SB_KEY}" -H "Authorization: Bearer ${SB_KEY}" \
| jq '.[0].settings_json.pricing | {widths_selected, coatings, colors, profile_aliases}'

echo "== DRY_RUN (ai_suggest=false) =="
curl -sS -X POST "${SERVICE_URL}/api/enrich/dry_run" \
  -H "X-Internal-Secret: sec_roof_2026_go_strong" \
  -H "Content-Type: application/json" \
  -d "{
    \"organization_id\":\"${ORG}\",
    \"import_job_id\":\"${JOB}\",
    \"scope\":{\"only_where_null\": true, \"limit\": 2000},
    \"ai_suggest\": false
  }" | jq '.stats, (.questions|map(.type)|unique)'
